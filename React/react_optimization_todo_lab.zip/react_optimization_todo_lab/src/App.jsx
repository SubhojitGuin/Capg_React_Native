import React, { useState } from "react";
import { requests as initialRequests } from "./data/requests";
import SearchBar from "./components/SearchBar";
import FilterPanel from "./components/FilterPanel";
import SummaryCards from "./components/SummaryCards";
import RequestList from "./components/RequestList";
import AnalyticsPanel from "./components/AnalyticsPanel";
import ReportPanel from "./components/ReportPanel";
import RequestForm from "./components/RequestForm";

function App() {
  console.log("App re-rendered");

  const [requests, setRequests] = useState(initialRequests);
  const [searchText, setSearchText] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [sortBy, setSortBy] = useState("");
  const [selectedRequest, setSelectedRequest] = useState(null);

  const [formData, setFormData] = useState({
    residentName: "",
    mobile: "",
    area: "",
    category: "",
    description: "",
    priority: "",
    visitDate: "",
  });

  // TODO 1:
  // Students must optimize filtered and sorted requests using useMemo.
  let filteredRequests = requests.filter((req) => {
    return (
      req.area.toLowerCase().includes(searchText.toLowerCase()) ||
      req.category.toLowerCase().includes(searchText.toLowerCase())
    );
  });

  if (statusFilter) {
    filteredRequests = filteredRequests.filter((req) => req.status === statusFilter);
  }

  if (sortBy === "priority") {
    filteredRequests.sort((a, b) => a.priority.localeCompare(b.priority));
  }

  if (sortBy === "date") {
    filteredRequests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  // TODO 2:
  // Students must convert these handlers to useCallback wherever useful.
  const handleViewDetails = (request) => {
    setSelectedRequest(request);
  };

  const handleResolve = (id) => {
    const updated = requests.map((req) =>
      req.id === id ? { ...req, status: "Resolved" } : req
    );
    setRequests(updated);
  };

  // TODO 3:
  // Students should analyze and improve the controlled form rendering.
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();

    const newRequest = {
      id: requests.length + 1,
      residentName: formData.residentName,
      area: formData.area,
      category: formData.category,
      description: formData.description,
      priority: formData.priority,
      status: "Open",
      assignedWorker: "N/A",
      createdAt: new Date().toISOString().split("T")[0],
    };

    setRequests((prev) => [...prev, newRequest]);

    setFormData({
      residentName: "",
      mobile: "",
      area: "",
      category: "",
      description: "",
      priority: "",
      visitDate: "",
    });
  };

  return (
    <div className="app-container">
      <h1>Neighborhood Service Request Dashboard - Optimization Lab</h1>

      <div className="card">
        <span className="tag">useMemo</span>
        <span className="tag">useCallback</span>
        <span className="tag">React.memo</span>
        <span className="tag">lazy loading</span>
        <span className="tag">controlled components</span>
        <span className="tag">debounce</span>
        <p>
          Students must analyze the application and implement the required optimization technique in the right place.
        </p>
      </div>

      <SummaryCards requests={requests} />

      <SearchBar searchText={searchText} onSearch={(value) => setSearchText(value)} />

      <FilterPanel
        statusFilter={statusFilter}
        sortBy={sortBy}
        onStatusChange={(value) => setStatusFilter(value)}
        onSortChange={(value) => setSortBy(value)}
      />

      <RequestForm formData={formData} onChange={handleInputChange} onSubmit={handleFormSubmit} />

      <RequestList
        requests={filteredRequests}
        onViewDetails={handleViewDetails}
        onResolve={handleResolve}
      />

      {/* TODO 4:
          Students must lazy load AnalyticsPanel and ReportPanel using React.lazy and Suspense.
      */}
      <AnalyticsPanel requests={requests} />
      <ReportPanel selectedRequest={selectedRequest} />

      <div className="card">
        <h3 className="section-title">Student Deliverables</h3>
        <ol>
          <li>Identify unnecessary re-renders using console logs.</li>
          <li>Apply useMemo for expensive derived data.</li>
          <li>Apply useCallback for stable function references.</li>
          <li>Use React.memo where needed.</li>
          <li>Implement lazy loading and Suspense for heavy components.</li>
          <li>Optimize the form by splitting and memoizing fields.</li>
          <li>Optionally add debounced search.</li>
        </ol>
      </div>
    </div>
  );
}

export default App;
