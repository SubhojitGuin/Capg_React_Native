import React from "react";

function SummaryCards({ requests }) {
  console.log("SummaryCards re-rendered");

  // TODO: Students should optimize these repeated calculations using useMemo.
  const total = requests.length;
  const openCount = requests.filter((r) => r.status === "Open").length;
  const resolvedCount = requests.filter((r) => r.status === "Resolved").length;
  const highPriority = requests.filter((r) => r.priority === "High").length;

  return (
    <div className="summary-grid">
      <div className="summary-card">Total Requests: {total}</div>
      <div className="summary-card">Open: {openCount}</div>
      <div className="summary-card">Resolved: {resolvedCount}</div>
      <div className="summary-card">High Priority: {highPriority}</div>
    </div>
  );
}

export default SummaryCards;
