import React from "react";

function RequestForm({ formData, onChange, onSubmit }) {
  console.log("RequestForm re-rendered");

  return (
    <div className="card">
      <h3>New Request Form</h3>
      <form onSubmit={onSubmit} className="form-grid">
        <input
          type="text"
          name="residentName"
          placeholder="Resident Name"
          value={formData.residentName}
          onChange={onChange}
        />

        <input
          type="text"
          name="mobile"
          placeholder="Mobile Number"
          value={formData.mobile}
          onChange={onChange}
        />

        <input
          type="text"
          name="area"
          placeholder="Area"
          value={formData.area}
          onChange={onChange}
        />

        <select name="category" value={formData.category} onChange={onChange}>
          <option value="">Select Category</option>
          <option value="Water Leakage">Water Leakage</option>
          <option value="Garbage Pickup">Garbage Pickup</option>
          <option value="Streetlight Issue">Streetlight Issue</option>
          <option value="Road Damage">Road Damage</option>
          <option value="Drainage Blockage">Drainage Blockage</option>
        </select>

        <select name="priority" value={formData.priority} onChange={onChange}>
          <option value="">Select Priority</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>

        <input
          type="date"
          name="visitDate"
          value={formData.visitDate}
          onChange={onChange}
        />

        <textarea
          name="description"
          placeholder="Description"
          value={formData.description}
          onChange={onChange}
        />

        <button type="submit">Add Request</button>
      </form>

      <div className="todo-box">
        <strong>TODO:</strong> Split this form into smaller field components and optimize the controlled component behavior.
      </div>
    </div>
  );
}

export default RequestForm;
